// Auto-filled with your Firebase web app configuration.
// (This config is safe to be public for Firebase client apps.)
export const firebaseConfig = {
  apiKey: "AIzaSyDnnK5Wfc1e-DOU7XyPR-hOb_RHb44xtts",
  authDomain: "copyfy-2c025.firebaseapp.com",
  projectId: "copyfy-2c025",
  storageBucket: "copyfy-2c025.firebasestorage.app",
  messagingSenderId: "936701831666",
  appId: "1:936701831666:web:1aa355d9c49483af07236b",
  measurementId: "G-PDSGGRC5Q3"
};
